﻿namespace minoan_museum1
{
    partial class Form8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form8));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.τοΜουσείοToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ιστορικόToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.εκθέματαToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.οΔίσκοςΤηςΦαιστούToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.περίαπτοΜεΜέλισσεςToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fotoGalleryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ώρεςΛειτουργίαςToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.επικοινωνίαToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.αρχικήToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.αρχικήToolStripMenuItem,
            this.τοΜουσείοToolStripMenuItem,
            this.ιστορικόToolStripMenuItem,
            this.εκθέματαToolStripMenuItem,
            this.fotoGalleryToolStripMenuItem,
            this.ώρεςΛειτουργίαςToolStripMenuItem,
            this.επικοινωνίαToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(838, 27);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // τοΜουσείοToolStripMenuItem
            // 
            this.τοΜουσείοToolStripMenuItem.Name = "τοΜουσείοToolStripMenuItem";
            this.τοΜουσείοToolStripMenuItem.Size = new System.Drawing.Size(92, 23);
            this.τοΜουσείοToolStripMenuItem.Text = "Το Μουσείο";
            this.τοΜουσείοToolStripMenuItem.Click += new System.EventHandler(this.τοΜουσείοToolStripMenuItem_Click);
            // 
            // ιστορικόToolStripMenuItem
            // 
            this.ιστορικόToolStripMenuItem.Name = "ιστορικόToolStripMenuItem";
            this.ιστορικόToolStripMenuItem.Size = new System.Drawing.Size(73, 23);
            this.ιστορικόToolStripMenuItem.Text = "Ιστορικό";
            this.ιστορικόToolStripMenuItem.Click += new System.EventHandler(this.ιστορικόToolStripMenuItem_Click);
            // 
            // εκθέματαToolStripMenuItem
            // 
            this.εκθέματαToolStripMenuItem.BackColor = System.Drawing.Color.Gray;
            this.εκθέματαToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.οΔίσκοςΤηςΦαιστούToolStripMenuItem,
            this.ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem,
            this.ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem,
            this.περίαπτοΜεΜέλισσεςToolStripMenuItem,
            this.τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem,
            this.τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem,
            this.τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem});
            this.εκθέματαToolStripMenuItem.Name = "εκθέματαToolStripMenuItem";
            this.εκθέματαToolStripMenuItem.Size = new System.Drawing.Size(77, 23);
            this.εκθέματαToolStripMenuItem.Text = "Εκθέματα";
            // 
            // οΔίσκοςΤηςΦαιστούToolStripMenuItem
            // 
            this.οΔίσκοςΤηςΦαιστούToolStripMenuItem.Name = "οΔίσκοςΤηςΦαιστούToolStripMenuItem";
            this.οΔίσκοςΤηςΦαιστούToolStripMenuItem.Size = new System.Drawing.Size(338, 24);
            this.οΔίσκοςΤηςΦαιστούToolStripMenuItem.Text = "Ο δίσκος της Φαιστού";
            this.οΔίσκοςΤηςΦαιστούToolStripMenuItem.Click += new System.EventHandler(this.οΔίσκοςΤηςΦαιστούToolStripMenuItem_Click);
            // 
            // ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem
            // 
            this.ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem.Name = "ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem";
            this.ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem.Size = new System.Drawing.Size(338, 24);
            this.ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem.Text = "Ρυτό σε σχήμα ταυροκεφαλής";
            this.ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem.Click += new System.EventHandler(this.ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem_Click);
            // 
            // ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem
            // 
            this.ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem.Name = "ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem";
            this.ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem.Size = new System.Drawing.Size(338, 24);
            this.ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem.Text = "Ειδώλιο της μικρής \"θεάς των όφεων\"";
            this.ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem.Click += new System.EventHandler(this.ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem_Click);
            // 
            // περίαπτοΜεΜέλισσεςToolStripMenuItem
            // 
            this.περίαπτοΜεΜέλισσεςToolStripMenuItem.BackColor = System.Drawing.Color.DarkGray;
            this.περίαπτοΜεΜέλισσεςToolStripMenuItem.Checked = true;
            this.περίαπτοΜεΜέλισσεςToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.περίαπτοΜεΜέλισσεςToolStripMenuItem.Name = "περίαπτοΜεΜέλισσεςToolStripMenuItem";
            this.περίαπτοΜεΜέλισσεςToolStripMenuItem.Size = new System.Drawing.Size(338, 24);
            this.περίαπτοΜεΜέλισσεςToolStripMenuItem.Text = "Περίαπτο με μέλισσες";
            // 
            // τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem
            // 
            this.τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem.Name = "τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem";
            this.τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem.Size = new System.Drawing.Size(338, 24);
            this.τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem.Text = "Τοιχογραφία του \"Πρίγκηπα με τα κρίνα\"";
            this.τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem.Click += new System.EventHandler(this.τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem_Click);
            // 
            // τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem
            // 
            this.τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem.Name = "τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem";
            this.τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem.Size = new System.Drawing.Size(338, 24);
            this.τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem.Text = "Τοιχογραφία με παράσταση ταυροκαθαψίων";
            this.τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem.Click += new System.EventHandler(this.τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem_Click);
            // 
            // τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem
            // 
            this.τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem.Name = "τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem";
            this.τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem.Size = new System.Drawing.Size(338, 24);
            this.τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem.Text = "Τρίωτος αμφορέας ανακτορικού ρυθμού";
            this.τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem.Click += new System.EventHandler(this.τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem_Click);
            // 
            // fotoGalleryToolStripMenuItem
            // 
            this.fotoGalleryToolStripMenuItem.Name = "fotoGalleryToolStripMenuItem";
            this.fotoGalleryToolStripMenuItem.Size = new System.Drawing.Size(99, 23);
            this.fotoGalleryToolStripMenuItem.Text = "Foto Gallery";
            this.fotoGalleryToolStripMenuItem.Click += new System.EventHandler(this.fotoGalleryToolStripMenuItem_Click);
            // 
            // ώρεςΛειτουργίαςToolStripMenuItem
            // 
            this.ώρεςΛειτουργίαςToolStripMenuItem.Name = "ώρεςΛειτουργίαςToolStripMenuItem";
            this.ώρεςΛειτουργίαςToolStripMenuItem.Size = new System.Drawing.Size(130, 23);
            this.ώρεςΛειτουργίαςToolStripMenuItem.Text = "Ώρες Λειτουργίας";
            this.ώρεςΛειτουργίαςToolStripMenuItem.Click += new System.EventHandler(this.ώρεςΛειτουργίαςToolStripMenuItem_Click);
            // 
            // επικοινωνίαToolStripMenuItem
            // 
            this.επικοινωνίαToolStripMenuItem.Name = "επικοινωνίαToolStripMenuItem";
            this.επικοινωνίαToolStripMenuItem.Size = new System.Drawing.Size(92, 23);
            this.επικοινωνίαToolStripMenuItem.Text = "Επικοινωνία";
            this.επικοινωνίαToolStripMenuItem.Click += new System.EventHandler(this.επικοινωνίαToolStripMenuItem_Click);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.textBox1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.textBox1.Location = new System.Drawing.Point(12, 208);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(814, 183);
            this.textBox1.TabIndex = 6;
            this.textBox1.Text = resources.GetString("textBox1.Text");
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.ImageLocation = "";
            this.pictureBox1.Location = new System.Drawing.Point(12, 30);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(217, 172);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.button1.Location = new System.Drawing.Point(12, 416);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(76, 31);
            this.button1.TabIndex = 8;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.button2.Location = new System.Drawing.Point(747, 416);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(79, 31);
            this.button2.TabIndex = 9;
            this.button2.Text = "About";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // αρχικήToolStripMenuItem
            // 
            this.αρχικήToolStripMenuItem.Name = "αρχικήToolStripMenuItem";
            this.αρχικήToolStripMenuItem.Size = new System.Drawing.Size(64, 23);
            this.αρχικήToolStripMenuItem.Text = "Αρχική";
            this.αρχικήToolStripMenuItem.Click += new System.EventHandler(this.αρχικήToolStripMenuItem_Click);
            // 
            // Form8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(838, 459);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form8";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Περίαπτο με μέλισσες";
            this.Load += new System.EventHandler(this.Form8_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem τοΜουσείοToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ιστορικόToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem εκθέματαToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem οΔίσκοςΤηςΦαιστούToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem περίαπτοΜεΜέλισσεςToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fotoGalleryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ώρεςΛειτουργίαςToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem επικοινωνίαToolStripMenuItem;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ToolStripMenuItem αρχικήToolStripMenuItem;
    }
}