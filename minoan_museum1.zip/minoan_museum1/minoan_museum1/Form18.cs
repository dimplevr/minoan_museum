﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace minoan_museum1
{
    public partial class Form18 : Form
    {
        public Form18()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void Form18_Load(object sender, EventArgs e)
        {
            label2.Text = Form1.SetValueForText1;
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\raz\Desktop\minoan_museum1\database\Members.mdf;Integrated Security=True;Connect Timeout=30");
            SqlDataAdapter sda = new SqlDataAdapter("Select Id From Login where Username='"+Form1.SetValueForText1+"'", con);
            /*Δημιουργία αντικειμένου dt.Αντιπροσωπεύει έναν πίνακα δεδομένων στην μνήμη*/
             DataTable dt = new DataTable();
            /*Γέμισμα του πίνακα dt με τα δεδομένα του adapter*/
             sda.Fill(dt);
             String query = "select * from history where Id='" + dt.Rows[0][0].ToString() + "'";
             
             SqlCommand cmd = new SqlCommand(query, con);
          
             DataTable ds = new DataTable();
           
          

            SqlDataAdapter da = new SqlDataAdapter(query, con);
            da.Fill(ds);
           
          
            if (ds.Rows[0][1].ToString() == "1")
             {

                 checkBox1.Checked = true;

             }
            
            if (ds.Rows[0][2].ToString() == "1")
            {

                checkBox2.Checked = true;

            }
            if (ds.Rows[0][3].ToString() == "1")
            {

                checkBox3.Checked = true;

            }
            if (ds.Rows[0][4].ToString() == "1")
            {

                checkBox4.Checked = true;

            }
            if (ds.Rows[0][5].ToString() == "1")
            {

                checkBox5.Checked = true;

            }
            if (ds.Rows[0][6].ToString() == "1")
            {

                checkBox6.Checked = true;

            }
            if (ds.Rows[0][7].ToString() == "1")
            {

                checkBox7.Checked = true;

            }
            if (ds.Rows[0][8].ToString() == "1")
            {

                checkBox8.Checked = true;

            }
            if (ds.Rows[0][9].ToString() == "1")
            {

                checkBox9.Checked = true;

            }
            if (ds.Rows[0][10].ToString() == "1")
            {

                checkBox10.Checked = true;

            }
            if (ds.Rows[0][11].ToString() == "1")
            {

                checkBox11.Checked = true;

            }
            if (ds.Rows[0][12].ToString() == "1")
            {

                checkBox12.Checked = true;

            }
            if (ds.Rows[0][13].ToString() == "1")
            {

                checkBox13.Checked = true;

            }
            if (ds.Rows[0][14].ToString() == "1")
            {

                checkBox14.Checked = true;

            }
            if (ds.Rows[0][15].ToString() == "1")
            {

                checkBox15.Checked = true;

            }
        
            

        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\raz\Desktop\minoan_museum1\database\Members.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select Id From Login where Username='" + Form1.SetValueForText1 + "'", con);
            /*Δημιουργία αντικειμένου dt.Αντιπροσωπεύει έναν πίνακα δεδομένων στην μνήμη*/
            DataTable dt = new DataTable();
            /*Γέμισμα του πίνακα dt με τα δεδομένα του adapter*/
            sda.Fill(dt);
            SqlCommand cmd = new SqlCommand(@"UPDATE history SET Form3=0,Form4=0,Form5=0,Form6=0,Form7=0,Form8=0,Form9=0,Form10=0,Form11=0,Form12=0,Form13=0,Form14=0,Form15=0,Form16=0,Form17=0  WHERE (Id='" + dt.Rows[0][0].ToString() + "')", con);
            cmd.ExecuteNonQuery();
            checkBox1.Checked = false; 
            checkBox2.Checked = false;
            checkBox3.Checked = false;
            checkBox4.Checked = false;
            checkBox5.Checked = false;
            checkBox6.Checked = false;
            checkBox7.Checked = false;
            checkBox8.Checked = false;
            checkBox9.Checked = false;
            checkBox10.Checked = false;
            checkBox11.Checked = false;
            checkBox12.Checked = false;
            checkBox13.Checked = false;
            checkBox14.Checked = false;
            checkBox15.Checked = false;
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Form2 frm = new Form2();
            frm.Show();
        }
    }
}
