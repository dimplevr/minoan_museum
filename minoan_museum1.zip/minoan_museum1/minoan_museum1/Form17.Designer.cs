﻿namespace minoan_museum1
{
    partial class Form17
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form17));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.τοΜουσείοToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ιστορικόToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.εκθέματαToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.οΔίσκοςΤηςΦαιστούToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.περίαπτοΜεΜέλισσεςToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fotoGalleryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ώρεςΛειτουργίαςToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.επικοινωνίαToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.αρχικήToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.αρχικήToolStripMenuItem,
            this.τοΜουσείοToolStripMenuItem,
            this.ιστορικόToolStripMenuItem,
            this.εκθέματαToolStripMenuItem,
            this.fotoGalleryToolStripMenuItem,
            this.ώρεςΛειτουργίαςToolStripMenuItem,
            this.επικοινωνίαToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1254, 27);
            this.menuStrip1.TabIndex = 9;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // τοΜουσείοToolStripMenuItem
            // 
            this.τοΜουσείοToolStripMenuItem.Name = "τοΜουσείοToolStripMenuItem";
            this.τοΜουσείοToolStripMenuItem.Size = new System.Drawing.Size(92, 23);
            this.τοΜουσείοToolStripMenuItem.Text = "Το Μουσείο";
            // 
            // ιστορικόToolStripMenuItem
            // 
            this.ιστορικόToolStripMenuItem.Name = "ιστορικόToolStripMenuItem";
            this.ιστορικόToolStripMenuItem.Size = new System.Drawing.Size(73, 23);
            this.ιστορικόToolStripMenuItem.Text = "Ιστορικό";
            // 
            // εκθέματαToolStripMenuItem
            // 
            this.εκθέματαToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.οΔίσκοςΤηςΦαιστούToolStripMenuItem,
            this.ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem,
            this.ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem,
            this.περίαπτοΜεΜέλισσεςToolStripMenuItem,
            this.τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem,
            this.τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem,
            this.τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem});
            this.εκθέματαToolStripMenuItem.Name = "εκθέματαToolStripMenuItem";
            this.εκθέματαToolStripMenuItem.Size = new System.Drawing.Size(77, 23);
            this.εκθέματαToolStripMenuItem.Text = "Εκθέματα";
            // 
            // οΔίσκοςΤηςΦαιστούToolStripMenuItem
            // 
            this.οΔίσκοςΤηςΦαιστούToolStripMenuItem.Name = "οΔίσκοςΤηςΦαιστούToolStripMenuItem";
            this.οΔίσκοςΤηςΦαιστούToolStripMenuItem.Size = new System.Drawing.Size(338, 24);
            this.οΔίσκοςΤηςΦαιστούToolStripMenuItem.Text = "Ο δίσκος της Φαιστού";
            // 
            // ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem
            // 
            this.ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem.Name = "ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem";
            this.ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem.Size = new System.Drawing.Size(338, 24);
            this.ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem.Text = "Ρυτό σε σχήμα ταυροκεφαλής";
            // 
            // ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem
            // 
            this.ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem.Name = "ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem";
            this.ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem.Size = new System.Drawing.Size(338, 24);
            this.ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem.Text = "Ειδώλιο της μικρής \"θεάς των όφεων\"";
            // 
            // περίαπτοΜεΜέλισσεςToolStripMenuItem
            // 
            this.περίαπτοΜεΜέλισσεςToolStripMenuItem.Name = "περίαπτοΜεΜέλισσεςToolStripMenuItem";
            this.περίαπτοΜεΜέλισσεςToolStripMenuItem.Size = new System.Drawing.Size(338, 24);
            this.περίαπτοΜεΜέλισσεςToolStripMenuItem.Text = "Περίαπτο με μέλισσες";
            // 
            // τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem
            // 
            this.τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem.Name = "τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem";
            this.τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem.Size = new System.Drawing.Size(338, 24);
            this.τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem.Text = "Τοιχογραφία του \"Πρίγκηπα με τα κρίνα\"";
            // 
            // τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem
            // 
            this.τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem.Name = "τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem";
            this.τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem.Size = new System.Drawing.Size(338, 24);
            this.τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem.Text = "Τοιχογραφία με παράσταση ταυροκαθαψίων";
            // 
            // τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem
            // 
            this.τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem.Name = "τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem";
            this.τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem.Size = new System.Drawing.Size(338, 24);
            this.τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem.Text = "Τρίωτος αμφορέας ανακτορικού ρυθμού";
            // 
            // fotoGalleryToolStripMenuItem
            // 
            this.fotoGalleryToolStripMenuItem.Name = "fotoGalleryToolStripMenuItem";
            this.fotoGalleryToolStripMenuItem.Size = new System.Drawing.Size(99, 23);
            this.fotoGalleryToolStripMenuItem.Text = "Foto Gallery";
            // 
            // ώρεςΛειτουργίαςToolStripMenuItem
            // 
            this.ώρεςΛειτουργίαςToolStripMenuItem.Name = "ώρεςΛειτουργίαςToolStripMenuItem";
            this.ώρεςΛειτουργίαςToolStripMenuItem.Size = new System.Drawing.Size(130, 23);
            this.ώρεςΛειτουργίαςToolStripMenuItem.Text = "Ώρες Λειτουργίας";
            // 
            // επικοινωνίαToolStripMenuItem
            // 
            this.επικοινωνίαToolStripMenuItem.Name = "επικοινωνίαToolStripMenuItem";
            this.επικοινωνίαToolStripMenuItem.Size = new System.Drawing.Size(92, 23);
            this.επικοινωνίαToolStripMenuItem.Text = "Επικοινωνία";
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.button1.Location = new System.Drawing.Point(12, 522);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(76, 31);
            this.button1.TabIndex = 19;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.button2.Location = new System.Drawing.Point(870, 522);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(79, 31);
            this.button2.TabIndex = 20;
            this.button2.Text = "About";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.monthCalendar1.Location = new System.Drawing.Point(12, 51);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 21;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 7;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.06897F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.93103F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 142F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 136F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 131F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 135F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 126F));
            this.tableLayoutPanel1.Location = new System.Drawing.Point(251, 95);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 48.78049F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 51.21951F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 85F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 93F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 89F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(936, 421);
            this.tableLayoutPanel1.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(296, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 23;
            this.label1.Text = "ΔΕΥΤΕΡΑ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(442, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 24;
            this.label2.Text = "ΤΡΙΤΗ";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(566, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 25;
            this.label3.Text = "ΤΕΤΑΡΤΗ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(709, 72);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 26;
            this.label4.Text = "ΠΕΜΠΤΗ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(831, 72);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 13);
            this.label5.TabIndex = 27;
            this.label5.Text = "ΠΑΡΑΣΚΕΥΗ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(968, 72);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 13);
            this.label6.TabIndex = 28;
            this.label6.Text = "ΣΑΒΒΑΤΟ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1096, 72);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 13);
            this.label7.TabIndex = 29;
            this.label7.Text = "ΚΥΡΙΑΚΗ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(1190, 133);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 13);
            this.label8.TabIndex = 30;
            this.label8.Text = "WEEK1";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1190, 200);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(45, 13);
            this.label9.TabIndex = 31;
            this.label9.Text = "WEEK2";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(1190, 286);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(45, 13);
            this.label10.TabIndex = 32;
            this.label10.Text = "WEEK3";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(1190, 371);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(45, 13);
            this.label11.TabIndex = 33;
            this.label11.Text = "WEEK4";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1193, 468);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(45, 13);
            this.label12.TabIndex = 34;
            this.label12.Text = "WEEK5";
            // 
            // αρχικήToolStripMenuItem
            // 
            this.αρχικήToolStripMenuItem.Name = "αρχικήToolStripMenuItem";
            this.αρχικήToolStripMenuItem.Size = new System.Drawing.Size(64, 23);
            this.αρχικήToolStripMenuItem.Text = "Αρχική";
            // 
            // Form17
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1254, 565);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.monthCalendar1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form17";
            this.Text = "Events";
            this.Load += new System.EventHandler(this.Form17_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem τοΜουσείοToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ιστορικόToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem εκθέματαToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem οΔίσκοςΤηςΦαιστούToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem περίαπτοΜεΜέλισσεςToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fotoGalleryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ώρεςΛειτουργίαςToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem επικοινωνίαToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ToolStripMenuItem αρχικήToolStripMenuItem;
    }
}