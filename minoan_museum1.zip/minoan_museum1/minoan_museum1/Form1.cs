﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace minoan_museum1
{
    public partial class Form1 : Form
    {
        public static String SetValueForText1 = ""; // Global μεταβλητή που την βλέπουν όλες οι φόρμες
       
        public Form1()
        {
            InitializeComponent();
            textBox2.PasswordChar = '*'; //Θέτουμε οι χαρακτήρες του κειμένου στο πεδίο Password να είναι με το σύμβλο *
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form15 frm = new Form15();
            frm.Show();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {
            
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
          groupBox2.Enabled = true;
          button1.Enabled = false;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            groupBox2.Enabled = false;
            button1.Enabled = true;

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            SetValueForText1 = "Επισκέπτης";
            Form2 frm = new Form2();
            frm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            /*Σύνδεση στη ΒΔ Members που δημιουργήσαμε για τα στοιχεία των εγγεγραμμένων χρηστών*/
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\raz\Desktop\minoan_museum1\database\Members.mdf;Integrated Security=True;Connect Timeout=30");
            /*Αντιπροσωπεύει ένα σύνολο εντολών και δεδομένων της ΒΔ Members που χρησιμοποιείται για να γεμίσει τον dt και να ενημερωθεί η ΒΔ*/
            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) From Login where Username='" + textBox1.Text + "' and Password='" + textBox2.Text + "'", con);
            /*Δημιουργία αντικειμένου dt.Αντιπροσωπεύει έναν πίνακα δεδομένων στην μνήμη*/
            DataTable dt = new DataTable();
            /*Γέμισμα του πίνακα dt με τα δεδομένα του adapter*/
            sda.Fill(dt);
            /*Έλεγχος κενών πεδίων στην φόρμα*/
            if (textBox1.TextLength==0 || textBox2.TextLength==0)
            {
                MessageBox.Show("Συμπλήρωσε υποχρεωτικά και τα δύο πεδία");
            }
            /*Έλεγχος για το αν τα στοιχεία που δόθηκαν ταιριάζουν με τις εγγραφές του πίνακα Login της ΒΔ Members*/
            else if (dt.Rows[0][0].ToString() == "1")
            {
                this.Hide();
                SetValueForText1 = textBox1.Text;
                Form2 frm = new Form2();
                frm.Show();
              
            }
            else
            {
                MessageBox.Show("Δεν βρέθηκε εγγραφή με το username και το password που δώσατε.Προσπαθήστε ξανά");
            }
        }
    }

    
}
