﻿namespace minoan_museum1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.αρχικήToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.τοΜουσείοToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ιστορικόToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.εκθέματαToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.οΔίσκοςΤηςΦαιστούToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.περίαπτοΜεΜέλισσεςToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fotoGalleryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ώρεςΛειτουργίαςToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.επικοινωνίαToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.αρχικήToolStripMenuItem,
            this.τοΜουσείοToolStripMenuItem,
            this.ιστορικόToolStripMenuItem,
            this.εκθέματαToolStripMenuItem,
            this.fotoGalleryToolStripMenuItem,
            this.ώρεςΛειτουργίαςToolStripMenuItem,
            this.επικοινωνίαToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(801, 27);
            this.menuStrip1.TabIndex = 9;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // αρχικήToolStripMenuItem
            // 
            this.αρχικήToolStripMenuItem.BackColor = System.Drawing.Color.Gray;
            this.αρχικήToolStripMenuItem.Checked = true;
            this.αρχικήToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.αρχικήToolStripMenuItem.Name = "αρχικήToolStripMenuItem";
            this.αρχικήToolStripMenuItem.Size = new System.Drawing.Size(64, 23);
            this.αρχικήToolStripMenuItem.Text = "Αρχική";
            // 
            // τοΜουσείοToolStripMenuItem
            // 
            this.τοΜουσείοToolStripMenuItem.Name = "τοΜουσείοToolStripMenuItem";
            this.τοΜουσείοToolStripMenuItem.Size = new System.Drawing.Size(92, 23);
            this.τοΜουσείοToolStripMenuItem.Text = "Το Μουσείο";
            this.τοΜουσείοToolStripMenuItem.Click += new System.EventHandler(this.τοΜουσείοToolStripMenuItem_Click);
            // 
            // ιστορικόToolStripMenuItem
            // 
            this.ιστορικόToolStripMenuItem.Name = "ιστορικόToolStripMenuItem";
            this.ιστορικόToolStripMenuItem.Size = new System.Drawing.Size(73, 23);
            this.ιστορικόToolStripMenuItem.Text = "Ιστορικό";
            this.ιστορικόToolStripMenuItem.Click += new System.EventHandler(this.ιστορικόToolStripMenuItem_Click);
            // 
            // εκθέματαToolStripMenuItem
            // 
            this.εκθέματαToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.οΔίσκοςΤηςΦαιστούToolStripMenuItem,
            this.ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem,
            this.ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem,
            this.περίαπτοΜεΜέλισσεςToolStripMenuItem,
            this.τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem,
            this.τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem,
            this.τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem});
            this.εκθέματαToolStripMenuItem.Name = "εκθέματαToolStripMenuItem";
            this.εκθέματαToolStripMenuItem.Size = new System.Drawing.Size(77, 23);
            this.εκθέματαToolStripMenuItem.Text = "Εκθέματα";
            // 
            // οΔίσκοςΤηςΦαιστούToolStripMenuItem
            // 
            this.οΔίσκοςΤηςΦαιστούToolStripMenuItem.Name = "οΔίσκοςΤηςΦαιστούToolStripMenuItem";
            this.οΔίσκοςΤηςΦαιστούToolStripMenuItem.Size = new System.Drawing.Size(338, 24);
            this.οΔίσκοςΤηςΦαιστούToolStripMenuItem.Text = "Ο δίσκος της Φαιστού";
            this.οΔίσκοςΤηςΦαιστούToolStripMenuItem.Click += new System.EventHandler(this.οΔίσκοςΤηςΦαιστούToolStripMenuItem_Click);
            // 
            // ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem
            // 
            this.ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem.Name = "ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem";
            this.ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem.Size = new System.Drawing.Size(338, 24);
            this.ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem.Text = "Ρυτό σε σχήμα ταυροκεφαλής";
            this.ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem.Click += new System.EventHandler(this.ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem_Click);
            // 
            // ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem
            // 
            this.ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem.Name = "ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem";
            this.ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem.Size = new System.Drawing.Size(338, 24);
            this.ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem.Text = "Ειδώλιο της μικρής \"θεάς των όφεων\"";
            this.ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem.Click += new System.EventHandler(this.ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem_Click);
            // 
            // περίαπτοΜεΜέλισσεςToolStripMenuItem
            // 
            this.περίαπτοΜεΜέλισσεςToolStripMenuItem.Name = "περίαπτοΜεΜέλισσεςToolStripMenuItem";
            this.περίαπτοΜεΜέλισσεςToolStripMenuItem.Size = new System.Drawing.Size(338, 24);
            this.περίαπτοΜεΜέλισσεςToolStripMenuItem.Text = "Περίαπτο με μέλισσες";
            this.περίαπτοΜεΜέλισσεςToolStripMenuItem.Click += new System.EventHandler(this.περίαπτοΜεΜέλισσεςToolStripMenuItem_Click);
            // 
            // τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem
            // 
            this.τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem.Name = "τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem";
            this.τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem.Size = new System.Drawing.Size(338, 24);
            this.τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem.Text = "Τοιχογραφία του \"Πρίγκηπα με τα κρίνα\"";
            this.τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem.Click += new System.EventHandler(this.τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem_Click);
            // 
            // τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem
            // 
            this.τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem.Name = "τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem";
            this.τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem.Size = new System.Drawing.Size(338, 24);
            this.τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem.Text = "Τοιχογραφία με παράσταση ταυροκαθαψίων";
            this.τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem.Click += new System.EventHandler(this.τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem_Click);
            // 
            // τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem
            // 
            this.τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem.Name = "τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem";
            this.τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem.Size = new System.Drawing.Size(338, 24);
            this.τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem.Text = "Τρίωτος αμφορέας ανακτορικού ρυθμού";
            this.τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem.Click += new System.EventHandler(this.τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem_Click);
            // 
            // fotoGalleryToolStripMenuItem
            // 
            this.fotoGalleryToolStripMenuItem.Name = "fotoGalleryToolStripMenuItem";
            this.fotoGalleryToolStripMenuItem.Size = new System.Drawing.Size(99, 23);
            this.fotoGalleryToolStripMenuItem.Text = "Foto Gallery";
            this.fotoGalleryToolStripMenuItem.Click += new System.EventHandler(this.fotoGalleryToolStripMenuItem_Click);
            // 
            // ώρεςΛειτουργίαςToolStripMenuItem
            // 
            this.ώρεςΛειτουργίαςToolStripMenuItem.Name = "ώρεςΛειτουργίαςToolStripMenuItem";
            this.ώρεςΛειτουργίαςToolStripMenuItem.Size = new System.Drawing.Size(130, 23);
            this.ώρεςΛειτουργίαςToolStripMenuItem.Text = "Ώρες Λειτουργίας";
            this.ώρεςΛειτουργίαςToolStripMenuItem.Click += new System.EventHandler(this.ώρεςΛειτουργίαςToolStripMenuItem_Click);
            // 
            // επικοινωνίαToolStripMenuItem
            // 
            this.επικοινωνίαToolStripMenuItem.Name = "επικοινωνίαToolStripMenuItem";
            this.επικοινωνίαToolStripMenuItem.Size = new System.Drawing.Size(92, 23);
            this.επικοινωνίαToolStripMenuItem.Text = "Επικοινωνία";
            this.επικοινωνίαToolStripMenuItem.Click += new System.EventHandler(this.επικοινωνίαToolStripMenuItem_Click);
            // 
            // button2
            // 
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.button2.Location = new System.Drawing.Point(710, 402);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(79, 35);
            this.button2.TabIndex = 20;
            this.button2.Text = "About";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.Location = new System.Drawing.Point(377, 381);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(70, 56);
            this.button3.TabIndex = 21;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.Location = new System.Drawing.Point(377, 381);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(70, 56);
            this.button4.TabIndex = 22;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.button1.Location = new System.Drawing.Point(12, 402);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(79, 35);
            this.button1.TabIndex = 23;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label1.Location = new System.Drawing.Point(731, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 16);
            this.label1.TabIndex = 24;
            this.label1.Text = "label1";
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.Control;
            this.button5.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.button5.Location = new System.Drawing.Point(710, 30);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(79, 29);
            this.button5.TabIndex = 25;
            this.button5.Text = "Log out";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.button6.Location = new System.Drawing.Point(714, 65);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 33);
            this.button6.TabIndex = 26;
            this.button6.Text = "History";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(801, 449);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Μινωικό Μουσείο";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem τοΜουσείοToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ιστορικόToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem εκθέματαToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem οΔίσκοςΤηςΦαιστούToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem περίαπτοΜεΜέλισσεςToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fotoGalleryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ώρεςΛειτουργίαςToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem επικοινωνίαToolStripMenuItem;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem αρχικήToolStripMenuItem;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
    }
}