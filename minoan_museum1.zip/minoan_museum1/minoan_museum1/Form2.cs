﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using System.Data.SqlClient;

namespace minoan_museum1
{
    public partial class Form2 : Form
    {

        public Form2()
        {
            InitializeComponent();
            button4.Hide(); //Θέτουμε αρχικά το stop button να είναι κρυμμένο

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form15 frm = new Form15();
            frm.Show();
        }

        private void τοΜουσείοToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 frm = new Form3();
            frm.Show();
        }

        private void ιστορικόToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 frm = new Form4();
            frm.Show();
        }

        private void οΔίσκοςΤηςΦαιστούToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form5 frm = new Form5();
            frm.Show();
        }

        private void ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form6 frm = new Form6();
            frm.Show();
        }

        private void ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form7 frm = new Form7();
            frm.Show();
        }

        private void περίαπτοΜεΜέλισσεςToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form8 frm = new Form8();
            frm.Show();
        }

        private void τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form9 frm = new Form9();
            frm.Show();
        }

        private void τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form10 frm = new Form10();
            frm.Show();
        }

        private void τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form11 frm = new Form11();
            frm.Show();
        }

        private void fotoGalleryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form12 frm = new Form12();
            frm.Show();
        }

        private void ώρεςΛειτουργίαςToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form13 frm = new Form13();
            frm.Show();
        }

        private void επικοινωνίαToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form14 frm = new Form14();
            frm.Show();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            label1.Text = Form1.SetValueForText1;
            if (label1.Text == "Επισκέπτης")
            {
                button6.Enabled = false;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SoundPlayer player = new SoundPlayer(@"C:\Users\raz\Desktop\minoan_museum1\minoan_museum1\bin\Debug\song.wav"); //Δημιουργία του player αντικειμένου
            player.Play(); //Ξεκίνημα της μουσικής
            button3.Hide(); //Κρύψιμο του start sound button
            button4.Show(); //Εμφάνιση του stop button
           
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SoundPlayer player = new SoundPlayer(@"C:\Users\raz\Desktop\minoan_museum1\minoan_museum1\bin\Debug\song.wav");
            player.Stop(); //Σταμάτημα της μουσικής
            button4.Hide(); //Κρύψιμο του stop button
            button3.Show(); //Εμφάνιση του start sound button
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\raz\Desktop\minoan_museum1\database\Members.mdf;Integrated Security=True;Connect Timeout=30");
            con.Close();
            this.Close();
            Form1 frm = new Form1();
            frm.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form18 frm = new Form18();
            frm.Show();

        }
    }
}
