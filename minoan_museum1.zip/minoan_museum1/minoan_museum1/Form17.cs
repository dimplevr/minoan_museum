﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace minoan_museum1
{
    public partial class Form17 : Form
    {
        public Form17()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form15 frm = new Form15();
            frm.Show();
        }

        private void Form17_Load(object sender, EventArgs e)
        {
            if (Form1.SetValueForText1 == "Επισκέπτης")
            {
                MessageBox.Show("Δεν είστε εγγεγραμμένος χρήστης");
                this.Close();
                Form2 frm2 = new Form2();
                frm2.Show();
            }
            if (Form1.SetValueForText1 == "Επισκέπτης")
            {

            }
            else
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\raz\Desktop\minoan_museum1\database\Members.mdf;Integrated Security=True;Connect Timeout=30");
                con.Open();
                SqlDataAdapter sda = new SqlDataAdapter("Select Id From Login where Username='" + Form1.SetValueForText1 + "'", con);

                DataTable dt = new DataTable();

                sda.Fill(dt);
                SqlCommand cmd1 = new SqlCommand(@"UPDATE history SET Form17=1 WHERE (Id='" + dt.Rows[0][0].ToString() + "')", con);
                cmd1.ExecuteNonQuery();
            }
        }
    }
}
