﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace minoan_museum1
{
    public partial class Form15 : Form
    {
        public Form15()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
           
        }

        private void Form15_Load(object sender, EventArgs e)
        {
            if (Form1.SetValueForText1 == "Επισκέπτης")
            {

            }
            else
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\raz\Desktop\minoan_museum1\database\Members.mdf;Integrated Security=True;Connect Timeout=30");
                con.Open();
                SqlDataAdapter sda = new SqlDataAdapter("Select Id From Login where Username='" + Form1.SetValueForText1 + "'", con);

                DataTable dt = new DataTable();

                sda.Fill(dt);
                SqlCommand cmd1 = new SqlCommand(@"UPDATE history SET Form15=1 WHERE (Id='" + dt.Rows[0][0].ToString() + "')", con);
                cmd1.ExecuteNonQuery();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
