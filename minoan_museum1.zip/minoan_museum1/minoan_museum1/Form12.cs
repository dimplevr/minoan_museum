﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace minoan_museum1
{
    public partial class Form12 : Form
    {
        int imageNumber = 1;
        public Form12()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form15 frm = new Form15();
            frm.Show();
        }

        private void Form12_Load(object sender, EventArgs e)
        {
            if (Form1.SetValueForText1 == "Επισκέπτης")
            {
                MessageBox.Show("Δεν είστε εγγεγραμμένος χρήστης");
                this.Close();
                Form2 frm2 = new Form2();
                frm2.Show();
            }
            if (Form1.SetValueForText1 == "Επισκέπτης")
            {

            }
            else
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\raz\Desktop\minoan_museum1\database\Members.mdf;Integrated Security=True;Connect Timeout=30");
                con.Open();
                SqlDataAdapter sda = new SqlDataAdapter("Select Id From Login where Username='" + Form1.SetValueForText1 + "'", con);

                DataTable dt = new DataTable();

                sda.Fill(dt);
                SqlCommand cmd1 = new SqlCommand(@"UPDATE history SET Form12=1 WHERE (Id='" + dt.Rows[0][0].ToString() + "')", con);
                cmd1.ExecuteNonQuery();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            loadNextImage();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
           
        }

        private void loadNextImage()
        {
            if (imageNumber == 24)
            {
                imageNumber = 1;
            }
            pictureBox1.ImageLocation = string.Format(@"C:\Users\raz\Desktop\minoan_museum1\minoan_museum1\bin\Debug\images\image{0}.jpg", imageNumber);
            imageNumber++;
        }

        private void τοΜουσείοToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 frm = new Form3();
            frm.Show();
        }

        private void ιστορικόToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 frm = new Form4();
            frm.Show();
        }

        private void οΔίσκοςΤηςΦαιστούToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form5 frm = new Form5();
            frm.Show();
        }

        private void ρυτόΣεΣχήμαΤαυροκεφαλήςToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form6 frm = new Form6();
            frm.Show();
        }

        private void ειδώλιοΤηςΜικρήςθεάςΤωνΌφεωνToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form7 frm = new Form7();
            frm.Show();
        }

        private void περίαπτοΜεΜέλισσεςToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form8 frm = new Form8();
            frm.Show();
        }

        private void τοιχογραφίαΤουΠρίγκηπαΜεΤαΚρίναToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form9 frm = new Form9();
            frm.Show();
        }

        private void τοιχογραφίαΜεΠαράστασηΤαυροκαθαψίωνToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form10 frm = new Form10();
            frm.Show();
        }

        private void τρίωτοςΑμφορέαςΑνακτορικούΡυθμούToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form11 frm = new Form11();
            frm.Show();
        }

        private void ώρεςΛειτουργίαςToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form13 frm = new Form13();
            frm.Show();
        }

        private void επικοινωνίαToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form14 frm = new Form14();
            frm.Show();
        }

        private void αρχικήToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 frm = new Form2();
            frm.Show();
        }
    }
}
